import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inputboxes',
  templateUrl: './inputboxes.component.html',
  styleUrls: ['./inputboxes.component.css']
})
export class InputboxesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
